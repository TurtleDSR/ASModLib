enum ETimeDimension
{
	Past,
	Present
};