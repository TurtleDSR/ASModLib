class ACritterHole : AHazeActor
{
    
}